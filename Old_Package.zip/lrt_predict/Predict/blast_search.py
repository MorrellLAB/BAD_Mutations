#!/usr/bin/env python

#   A script that contains functions to do BLAST searching.
#   Modified from a script writted by Paul Hoffman.

#Import tBlastx command line function
try:
    from Bio.Blast.Applications import NcbitblastxCommandline
    from Bio.Blast import NCBIXML
except ImportError:
    print 'You need to have the Biopython library installed'
    exit(1)

#Define BLAST program
def run_blast(sequence, evalue, max_hits, database):
    tblastx_cline = NcbitblastxCommandline(query=sequence,
        out='tmp_result.xml',
        db=database,
        evalue=evalue,
        outfmt=5,
        max_target_seqs=max_hits)
    tblastx_cline()

#Define Parser
def get_gbID(threshold):
    result_handle = open('tmp_result.xml')
    blast_records = NCBIXML.parse(result_handle)
    blast_record = next(blast_records)
    try:
        while True:
            blast_record = next(blast_records)
    except StopIteration:
        pass
    parse_results = open("parse_results.txt", 'w')
    for alignment in blast_record.alignments:
        for hsp in alignment.hsps:
            if hsp.expect < threshold:
                print >> parse_results, '****Alignment****'
                print >> parse_results, 'sequence:', alignment.title
                print >> parse_results, 'evalue:', hsp.expect

def blast_parse():
    run_blast(args.sequence, args.evalue, args.max_hits, args.database)
    get_gbID(args.thresh)
